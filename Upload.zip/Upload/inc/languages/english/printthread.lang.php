<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

$l['forum'] = "Forum:";
$l['printable_version'] = "Printable Version";
$l['pages'] = "Pages:";
$l['thread'] = "Thread:";
