<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

$l['templates_and_style'] = "Templates &amp; Style";

$l['themes'] = "Themes";
$l['templates'] = "Templates";

$l['can_manage_themes'] = "Can manage themes?";
$l['can_manage_templates'] = "Can manage templates?";

